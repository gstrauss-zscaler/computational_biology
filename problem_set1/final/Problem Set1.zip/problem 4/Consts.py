from enum import IntEnum

class Choice(IntEnum):
    NONE = 0
    SUBSTITUTION = 1
    GAP_RIGHT = 2
    GAP_DOWN = 3